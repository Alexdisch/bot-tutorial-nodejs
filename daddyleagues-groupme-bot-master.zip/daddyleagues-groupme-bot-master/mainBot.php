<?php

// the main bot setup

include('./httpful.phar');
include('./functions.php');

// this is found at http://dev.groupme.com/bots
$bot_token = "the main bot id";

include('./index.php');

?>